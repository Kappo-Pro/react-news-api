import React from 'react';
import { useNavigate } from 'react-router-dom';

function App() {

  const navigate = useNavigate();

  return (
    <>
      <h1>About us page</h1>
      <button className='btn btn-primary' onClick={() => navigate('news-api')}>NEWS API</button>
      <button className='btn btn-primary' onClick={() => navigate('g-news')}>GNEWS</button>
    </>
  )
}

export default App